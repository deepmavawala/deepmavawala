﻿using CategoryManagement.Models;
using CategoryManagement.Models.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CategoryManagement.Controllers
{
    public class CategoryController : Controller
    {
        private readonly ApplicationDbContext _db;
        public CategoryController(ApplicationDbContext db) 
        {
            _db = db;
        }
        public IActionResult Index()
        {
            IEnumerable<Category> objcategorylist = _db.Categories; 
            return View(objcategorylist);
        }
        public IActionResult create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Category obj) 
        {
            if(ModelState.IsValid) 
            {
                _db.Categories.Add(obj);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(obj);
        }
        public IActionResult Edit(int? id)
        {
            List<Category> ctlist = _db.Categories.ToList();
            ViewBag.Categorytbl = new SelectList(ctlist, "CategoryId", "Name");


            var CategoryFromDb = _db.Categories.Find(id);
            return View(CategoryFromDb);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Category obj)
        {
            if (ModelState.IsValid) 
            {
                _db.Categories.Update(obj);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(obj);
        }
        public IActionResult Delete(int id) 
        {
            var categoryFromDb = _db.Categories.Find(id);
            return View(categoryFromDb);
        }
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeletePOST(int id)
        {
            var objCategory = _db.Categories.Find(id);
            _db.Categories.Remove(objCategory);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult AddChild(int id) 
        {
            ViewBag.Id = id;  
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddChild(Category obj) 
        {
            if(ModelState.IsValid) 
            {
                _db.Categories.Add(obj);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();
        }
        # region API CALLS
        [HttpGet]
        public IActionResult GetAll() 
        {
            var categorylist = _db.Categories.ToList();
            return Json(new { Data = categorylist });
        }
        #endregion
    }
}
