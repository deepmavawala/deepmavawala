﻿var dataTable
$(document).ready(function () {
    loadDataTable();
});
function loadDataTable() {
    dataTable = $('#tbldata').dataTable({
        "ajax": {
            "url": "/Category/getall"
        },
        "columns": [
            { "data": "name", "width": "15%" },
            { "data": "description", "width": "15%" },
            { "data": "isActive", "width": "15%" },
            {
                "data": "categoryId",
                "render": function (data) {
                    return `
                            <div class="w-75 btn-group" role="group">
                                 <a onclick="OutputPopup('/Category/Edit/?id=${data}','Edit Category')" class="btn btn-info">Edit Category</a>
                                 <a href="/Category/Delete/?id=${data}" class="btn btn-danger">Delete category</a>
                                 <a onclick="OutputPopup('/Category/AddChild/?id=${data}','Sub Category')" class="btn btn-secondary">Add sub-category</a>
                            </div>
                            `
                }, "width": "15%"
            }
        ]
    });
}
function OutputPopup(url, title) {
    $.ajax({
        type: "Get",
        url: url,
        success: function (data) {
            $('#popup .modal-body').html(data);
            $('#popup .modal-title').html(title);
            $('#popup').modal('show');
        }
    })
}

