﻿var dataTable
$(document).ready(function () {
    loadDataTable();
});
function loadDataTable() {
    dataTable = $('#tbldata').dataTable({
        "ajax": {
            "url": "/Category/getall"
        },
        "columns": [
            { "data": "name", "width": "15%" },
            { "data": "description", "width": "15%" },
            { "data": "isActive", "width": "15%" },
            { "data": "createdOn", "width": "15%" },
            {
                "data": "categoryId",
                "render": function (data) {
                    return `
                            <div class="w-75 btn-group" role="group">
                                 <a href="/Category/Edit/${data}" class="btn btn-info">Edit Category</a>
                                 <a href="/Category/Delete/${data}" class="btn btn-danger">Delete category</a>
                                 <a href="/Category/AddChild/${data}" class="btn btn-secondary">Add sub-category</a>
                            </div>
                            `
                },"width":"15%"
            }
        ]
    });
}